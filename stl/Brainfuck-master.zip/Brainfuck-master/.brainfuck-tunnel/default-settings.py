import app

app.default_settings()
