import app

app.reset_to_default_settings()
